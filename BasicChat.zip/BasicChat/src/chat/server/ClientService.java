package chat.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ClientService {
	
	ChatServer chatServer;
	Socket socket;
	
	DataInputStream dis;
	DataOutputStream dos;
	
	String clientIP;
	String chatName;
	String displayName;
	
	String whisper;
	String whisperName;
	
	LocalTime now;
	
	public String getLocalTime() {
		
		now = LocalTime.now();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
		
		String fNow = now.format(formatter);
		
		return fNow;
	}
	
	public ClientService(ChatServer chatServer, Socket socket) throws IOException {
		
		// 필요 자료 구조 초기화
		this.socket = socket;
		this.chatServer = chatServer;
		
		
		dis = new DataInputStream(socket.getInputStream());
		dos = new DataOutputStream(socket.getOutputStream());
		
		
		// 클라이언트 정보 수집 -> 서버한테 알려주기
		// InetAddress : 컴퓨터 이름을 가져온다
		clientIP = socket.getInetAddress().getHostName();
		chatName = dis.readUTF();
		displayName = chatName + "@" + clientIP;
		
		chatServer.addClientInfo(this);
		
		// 입장 알림 -> ChatServer에게 요청
		chatServer.sendToAll(this, "[입장]" + displayName);
		
		// 클라이언트 보낸 메시지를 다른 채팅 참여자에게 전송 -> ChatServer에게 요청 -> thread(Daemon)
		receive();
	}

	private void receive()  {
		new Thread(() ->{
			try {
				
				while(true) {
					String message = dis.readUTF();
					System.out.println("[" + getLocalTime() + "]" + displayName + ": " + message);
					String[] slash = message.split("", 2);
					
					
					if(slash[0].equals("/")) {
						if (serverCommand(message)) {
							break;
						}
					} else {
						chatServer.sendToAll(this, "[" + getLocalTime() + "]" +  displayName + ": " + message);
					}
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			quit();
		
		}).start();
	}
	
	private synchronized boolean serverCommand(String message) {
		
		String[] command = message.split(" ", 3);
		
		switch(command[0]) {
		case "/quit" : 
			return true;
		case "/rename" : 
			chatName = command[1];
			displayName = chatName + "@" + clientIP;
			return false;
		case "/to" :
			whisperName = command[1];
			whisper = command[2];
			chatServer.sendTo(this, whisper);
			return false;
		case "/img" :
			chatServer.sendImgMessage(this, command[1]);
			return false;
		}
		
		return false;
	}
	
		public void send(String message) {
			
			try {
				dos.writeUTF(message);
				dos.flush();
			} catch(IOException e) {
			
		}
	}

	private void quit() {
		// 다른 참여 클라이언트들에게 퇴장 정보를 전달
		chatServer.sendToAll(this, "[퇴장] " + displayName);
		//서버에 저장된 클라이언트 정보 삭제
		chatServer.removeClientInfo(this);
		
	}
	
	public void close() {
		// 할당 받은 자원 close()
				try {
					dis.close();
					dos.close();
					socket.close();
				} catch (IOException e) {
					
				}
	}
	
}
