package chat.server;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;
import java.util.Map;
import java.util.Scanner;

public class ChatServer {
	
	final String quitCommand = "quit";
	ServerSocket server;
	Map<String, ClientService> chatClientInfo = new Hashtable<>(); //해쉬 맵과 동일하지만 동기화 기능이 존재
	
	public void start(int portNo) {
		try {
			server = new ServerSocket(portNo);
			System.out.println("[채팅서버] 시작 (" + InetAddress.getLocalHost() + ":" + portNo + ")");
		} catch(Exception e) {
			System.out.println(e.toString());
		}
	}
	
	public void connectClient() {
		Thread thread = new Thread(() -> {
			try {
				while(true) {
					// 클라이언트 연결 요청에 대해 통신을 할 socket 생성
					Socket client = server.accept();
					new ClientService(this, client);
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		thread.setDaemon(true);
		thread.start();
	}
	
	public void stop() {
		try {
			server.close();
			System.out.println("[채팅서버] 종료");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void addClientInfo(ClientService clientService) {
		chatClientInfo.put(clientService.displayName, clientService);
		System.out.println("[입장]" + clientService.displayName + "(채팅 참여자 수 : " + chatClientInfo.size() + ")");
	}
	
	public void sendToAll(ClientService clientService, String message) {
		
		// 해당 client가 보낸 메시지를 다른 채팅 참여자들에게 전송
		for(ClientService cs : chatClientInfo.values()) {
			if(cs != clientService) {
				cs.send(message);
			}
		}
		
	}
	
	public void removeClientInfo(ClientService clientService) {
		chatClientInfo.remove(clientService.displayName);
		System.out.println("[퇴장] " + clientService.displayName + "(채팅 참여자 수 : " + chatClientInfo.size() + ")");
		
	}
	
	public void sendTo(ClientService clientService, String message) {
		
		// 해당 client가 보낸 메시지를 특정 채팅 참여자에게 전송
			for(ClientService cs : chatClientInfo.values()) {
				if(cs.chatName.equals(clientService.whisperName)) {	
					cs.send(clientService.chatName + "님의 귓속말 : " + message);
				}
			}
	}
	
	public void sendImgMessage(ClientService clientService, String img) {
		
		// 해당 client가 보낸 메시지를 다른 채팅 참여자들에게 전송
				for(ClientService cs : chatClientInfo.values()) {
					if(cs != clientService) {
						cs.send(clientService.chatName +"님이 보낸 파일 : " + img + "이미지 파일을 다운로드하시려면 /d를 입력하세요. ");
					}
				}
	}
	
	
	
	
	public static void main(String[] args) {
		
		final int portNo = 50005;
		
		ChatServer chatServer = new ChatServer();
		
		// 채팅 서버 시작(start)
		chatServer.start(portNo);
		
		// 클라이언트의 연결 요쳥을 받아서 채팅 서비스 제공 -> Daemon 처리 (connectClient)
		chatServer.connectClient();
		
		// 종료 command 처리 (stop)
		while (true){
		System.out.println("서버를 종료하려면 quit을 입력하고 Enter를 치세요 >> ");
		Scanner sc = new Scanner(System.in);
		String command = sc.nextLine();
		if (command.equalsIgnoreCase(chatServer.quitCommand)) {
			break;
			}
		}
		
		chatServer.stop();
		 
	}

}
