package chat.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient {

	String chatName;
	Socket socket;
	
	DataInputStream dis;
	DataOutputStream dos;
	
	private final static String quitCommand = "/quit";
	final String folderPath = "C:\\Chat_img\\"; 
	
	static File imgFolder;
	static File newImg;
	static Scanner sc = new Scanner(System.in);
	
	public void connect(String serverIP, int portNo, String chatName) {
		
	try {
		// 서버에 연결
		socket = new Socket(serverIP, portNo);
		
		dis = new DataInputStream(socket.getInputStream());
		dos = new DataOutputStream(socket.getOutputStream());
		
		// 대화명 저장하고 서버에 대화명을 알려줌
		this.chatName = chatName;
		send(chatName);
		
		System.out.println("[" + chatName + "] 채팅 서버 연결 성공 (" + serverIP + ":" + portNo + ")");
		
	} catch (Exception e) {
		e.printStackTrace();
	}
		
	}
	
	private void send(String message) {
		
		try {
			dos.writeUTF(message);
			dos.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	private void receive() {
		//Runnable 구현 람다식(run)
		Thread thread = new Thread(() -> {
			try {
				while (true) {
					String message = dis.readUTF();
					System.out.println(message);
					System.out.print("> ");
				}
			} catch (IOException e) {
				// 서버가 종료된 경우, dis가 close된 경우
				quit();
				System.exit(0);
			}
		});
		thread.setDaemon(true);
		thread.start();
	}
	
	public void rename(String chatName) {
		if(this.chatName.equals(chatName)) {
			System.out.println("중복되는 이름입니다.");
		} else {
			this.chatName = chatName;
		}
	}
	

	public static void main(String[] args) {
		
		final String serverIP = "localhost";
		final int portNo = 50005;
		
		ChatClient chatClient = new ChatClient();
		
		//대화명 입력을 받아서 서버 연결 시 전달
		System.out.print("대화명을 입력하세요 : ");
		
		String chatName = sc.nextLine();
		
		//서버 연결(connect)
		chatClient.connect(serverIP, portNo, chatName);
		
		// 채팅 서버로부터 메세지를 받아서 처리 -> thread 처리
		chatClient.receive();
		
		// 사용자가 입력한 메시지를 서버로 전송 (send)
		while (true) {
			System.out.print("> ");
			String message = sc.nextLine();
			chatClient.send(message);
			
			if(message.equals(quitCommand)) {
				break;
			}
			chatClient.clientCommand(message);
		}
		chatClient.quit();
	}

	

	private void clientCommand(String message) {
		
		String[] command = message.split(" ", 3);
		
		switch(command[0]) {
		case "/img" : 
			// 이미지 파일 경로 생성
			imgFolder = new File(folderPath + command[1]);
			newImg = new File("C:\\Chat_download_img" + command[1]);
			if(!imgFolder.exists() || !newImg.exists()) {
				System.out.println("c: 경로에 폴더 생성");
			} else {
				System.out.println("이미지 경로 생성");
			}
			break;
		case "/d" :
			
			try (
				 FileInputStream fis = new FileInputStream(imgFolder);
		         FileOutputStream fos = new FileOutputStream(newImg);
		       ) {

		            byte[] buffer = new byte[1024];
		            int bytesRead;

		            while ((bytesRead = fis.read(buffer)) != -1) {
		                fos.write(buffer);
		            }
		            fos.flush();
		            System.out.println("파일이 " + imgFolder.getAbsolutePath() + "에 저장되었습니다.");
		        } catch(Exception e) {
		        	e.printStackTrace();
		        	System.out.println("잘못되거나 존재하지 않는 경로입니다.");
		        }
		       	break;
		}
		
	}

	private void quit() {
		
		try {	
			dis.close();
			dos.close();
			socket.close();
			System.out.println("[" + chatName + "] 채팅 서버 연결 종료");
		} catch( Exception e) {
			
		}
		
	}

}
